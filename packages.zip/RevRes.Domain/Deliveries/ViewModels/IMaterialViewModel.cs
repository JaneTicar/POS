﻿using RevRes.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevRes.Domain.Deliveries.ViewModels
{
    public interface IMaterialViewModel
    {
        IEnumerable<Material> Materials { get; }
        Material SelectedMaterial { get; set; }
    }
}
