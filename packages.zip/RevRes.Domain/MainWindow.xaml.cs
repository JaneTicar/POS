﻿using RevRes.Domain.BLL;
using RevRes.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RevRes.POS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

            List<User> users = UsersBLL.GetAll();
            InitializeComponent();
        }

        private void btnMaterials_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnUser_Click_1(object sender, RoutedEventArgs e)
        {
            Users.List usersWindow = new Users.List();
            usersWindow.Show();
        }

        private void btnMenu_Click_1(object sender, RoutedEventArgs e)
        {
            POS.Categories.List categoryWindow = new POS.Categories.List();
            categoryWindow.Show();
        }


        private void btnOrders_Click_1(object sender, RoutedEventArgs e)
        {


        }

        private void btnOrdersItems_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void btnRecipe_Click_1(object sender, RoutedEventArgs e)
        {


        }

        private void btnSales_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void btnDelivery_Click(object sender, RoutedEventArgs e)
        {

            Deliveries.List deliveryWindow = new Deliveries.List();
            deliveryWindow.Show();
        }

        private void btnProduct_Click(object sender, RoutedEventArgs e)
        {
            POS.Products.List productWIndow = new POS.Products.List();
            productWIndow.Show();
        }
    }
}

