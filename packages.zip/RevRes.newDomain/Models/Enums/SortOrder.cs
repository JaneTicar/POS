﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevRes.Domain.Models.Enums
{
    public enum SortOrder
    {
        Ascending,
        Descending
    }
}

