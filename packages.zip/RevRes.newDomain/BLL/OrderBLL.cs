﻿using RevRes.Domain.Infrastructure;
using RevRes.Domain.Models;
using RevRes.Domain.Models.Enums;
using RevRes.newDomain.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevRes.newDomain.BLL
{
    public static class OrderBLL
    {
    }
}
